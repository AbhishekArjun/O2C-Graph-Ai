#!/bin/bash
# O2C Graph Intelligence - Startup Script

set -e

echo "======================================"
echo "  O2C Graph Intelligence System"
echo "======================================"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is required"
    exit 1
fi

# Install dependencies
echo "[1/3] Installing Python dependencies..."
pip install flask flask-cors anthropic --break-system-packages -q 2>/dev/null || \
pip install flask flask-cors anthropic -q

# Check if DB exists, if not run ingestion
DB_PATH="$SCRIPT_DIR/backend/o2c.db"
if [ ! -f "$DB_PATH" ]; then
    echo "[2/3] Building database (first-time setup)..."
    python3 backend/ingest.py
else
    echo "[2/3] Database found, skipping ingestion."
fi

# Start backend
echo "[3/3] Starting Flask API on port 5001..."
echo ""
echo "  Backend:  http://localhost:5001"
echo "  Frontend: Open frontend/index.html in your browser"
echo ""
echo "Press Ctrl+C to stop."
echo "======================================"

ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY:-""} python3 backend/app.py
