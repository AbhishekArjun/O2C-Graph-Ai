"""
O2C Graph Intelligence — Flask Backend
Serves: REST API on /api/* + frontend static files on /
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3, json, os, re
import anthropic

# ── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR     = os.path.dirname(__file__)
PROJECT_DIR  = os.path.dirname(BASE_DIR)
DB_PATH      = os.path.join(BASE_DIR, "o2c.db")
FRONTEND_DIR = os.path.join(PROJECT_DIR, "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

# ── Database helpers ────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def run_query(sql, params=()):
    conn = get_db()
    try:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        return rows, None
    except Exception as e:
        return None, str(e)
    finally:
        conn.close()

# ── LLM Schema + Prompt ─────────────────────────────────────────────────────

SCHEMA = """
SAP Order-to-Cash (O2C) SQLite database:

TABLES:
1. sales_order_headers — PK: salesOrder | soldToParty FK→business_partners.businessPartner
   Fields: salesOrderType, salesOrganization, distributionChannel, creationDate, createdByUser,
   totalNetAmount (INR), overallDeliveryStatus ('A'=not started,'B'=partial,'C'=complete),
   overallOrdReltdBillgStatus, requestedDeliveryDate, headerBillingBlockReason,
   deliveryBlockReason, incotermsClassification, incotermsLocation1, customerPaymentTerms

2. sales_order_items — PK: (salesOrder, salesOrderItem) | FK→sales_order_headers
   Fields: material (product code), requestedQuantity, requestedQuantityUnit, netAmount,
   materialGroup, productionPlant FK→plants.plant, storageLocation

3. business_partners (= Customers) — PK: businessPartner (same as customer field)
   Fields: businessPartnerName, businessPartnerFullName, businessPartnerCategory,
   businessPartnerGrouping, creationDate, businessPartnerIsBlocked, isMarkedForArchiving
   NOTE: Only 8 customers in dataset.

4. outbound_delivery_headers (= Deliveries) — PK: deliveryDocument
   shippingPoint FK→plants.plant
   Fields: creationDate, overallGoodsMovementStatus ('A'=not moved,'C'=complete),
   overallPickingStatus, hdrGeneralIncompletionStatus, headerBillingBlockReason,
   deliveryBlockReason, actualGoodsMovementDate

5. billing_documents — PK: billingDocument
   soldToParty FK→business_partners.businessPartner
   accountingDocument FK→journal_entry_items.accountingDocument
   Fields: billingDocumentType, creationDate, billingDocumentDate,
   billingDocumentIsCancelled (ALL=1 because table=billing_document_cancellations),
   totalNetAmount, transactionCurrency, companyCode, fiscalYear
   NOTE: All 80 records are cancellation documents (billingDocumentIsCancelled=1).

6. journal_entry_items (= Accounting/AR records) — PK: (accountingDocument, accountingDocumentItem)
   referenceDocument = billingDocument FK→billing_documents
   customer FK→business_partners.businessPartner
   Fields: companyCode, fiscalYear, glAccount, profitCenter, amountInTransactionCurrency,
   postingDate, documentDate, clearingDate, clearingAccountingDocument

7. payments — PK: (accountingDocument, accountingDocumentItem)
   accountingDocument FK→journal_entry_items
   customer FK→business_partners.businessPartner
   Fields: clearingDate, clearingAccountingDocument, amountInTransactionCurrency,
   transactionCurrency, postingDate, glAccount

8. plants — PK: plant | Fields: plantName, salesOrganization, distributionChannel, addressId

9. product_descriptions — PK: product | Fields: language, productDescription
   NOTE: product codes here (e.g. B89...) differ from SO item material codes (S89...).
   To join: use a JOIN between product_descriptions and sales_order_items via a
   shared prefix heuristic, or just query them separately.

10. customer_sales_area — PK: (customer, salesOrganization, distributionChannel)
    Fields: currency, customerPaymentTerms, incotermsClassification, incotermsLocation1

KEY JOINS:
  SO→Customer:  sales_order_headers.soldToParty = business_partners.businessPartner
  SO→Items:     sales_order_headers.salesOrder = sales_order_items.salesOrder
  Billing→Cust: billing_documents.soldToParty = business_partners.businessPartner
  Billing→Jrnl: journal_entry_items.referenceDocument = billing_documents.billingDocument
  Jrnl→Payment: payments.accountingDocument = journal_entry_items.accountingDocument
  Delivery→Plt: outbound_delivery_headers.shippingPoint = plants.plant

IMPORTANT NOTES:
  - No direct FK between sales_order_headers ↔ billing_documents
  - No direct FK between sales_order_headers ↔ outbound_delivery_headers
  - Amounts in INR. Use ROUND(x,2) for currency display.
  - For broken flows: use LEFT JOIN ... IS NULL or NOT EXISTS
  - Delivery status A=not started, B=partial, C=complete (same for goods movement)
"""

SYSTEM_PROMPT = f"""You are an expert SAP Order-to-Cash (O2C) data analyst assistant.

{SCHEMA}

## STRICT GUARDRAILS
If the user asks ANYTHING outside this O2C dataset domain — general knowledge, coding help,
creative writing, current events, opinions, math, jokes, weather, etc. — you MUST respond
with this EXACT text (starting with GUARDRAIL:):
GUARDRAIL: This system is designed to answer questions about the SAP Order-to-Cash dataset only. I can help you explore sales orders, billing documents, deliveries, payments, customers, plants, and products.

## RESPONSE FORMAT (for valid O2C questions)
Return ONLY valid JSON, no markdown fences, no explanation outside the JSON:
{{"sql": "SELECT ...", "insight": "1-2 sentence business interpretation", "highlighted_nodes": ["SO_740506", "CUST_320000083"]}}

## SQL RULES
- SQLite syntax only, SELECT queries only
- LIMIT 50 for list queries; no LIMIT for aggregations
- Use proper JOINs per the schema above
- Always alias columns clearly (e.g. COUNT(*) as total)
- For missing links (no direct FK): infer via shared soldToParty/customer + date proximity
- Node ID format: SO_<id>, CUST_<id>, BD_<id>, PLANT_<id>, DEL_<id>, JE_<id>, PAY_<id>
"""

# ── Frontend serving ────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

# ── API: Stats ──────────────────────────────────────────────────────────────

@app.route("/api/stats")
def get_stats():
    conn = get_db()
    s = {
        "salesOrders":    conn.execute("SELECT COUNT(*) FROM sales_order_headers").fetchone()[0],
        "customers":      conn.execute("SELECT COUNT(*) FROM business_partners").fetchone()[0],
        "billingDocs":    conn.execute("SELECT COUNT(*) FROM billing_documents").fetchone()[0],
        "deliveries":     conn.execute("SELECT COUNT(*) FROM outbound_delivery_headers").fetchone()[0],
        "products":       conn.execute("SELECT COUNT(*) FROM product_descriptions").fetchone()[0],
        "plants":         conn.execute("SELECT COUNT(*) FROM plants").fetchone()[0],
        "journalEntries": conn.execute("SELECT COUNT(*) FROM journal_entry_items").fetchone()[0],
        "payments":       conn.execute("SELECT COUNT(*) FROM payments").fetchone()[0],
        "graphEdges":     conn.execute("SELECT COUNT(*) FROM graph_edges").fetchone()[0],
        "totalRevenue":   conn.execute("SELECT ROUND(SUM(totalNetAmount),2) FROM sales_order_headers").fetchone()[0],
        "totalPayments":  conn.execute("SELECT ROUND(SUM(amountInTransactionCurrency),2) FROM payments").fetchone()[0],
        "cancelledBills": conn.execute("SELECT COUNT(*) FROM billing_documents WHERE billingDocumentIsCancelled=1").fetchone()[0],
    }
    conn.close()
    return jsonify(s)

# ── API: Graph ──────────────────────────────────────────────────────────────

NODE_PREFIX = {
    "Customer":"CUST_","SalesOrder":"SO_","BillingDocument":"BD_",
    "Plant":"PLANT_","Delivery":"DEL_","JournalEntry":"JE_",
    "Payment":"PAY_","Material":"MAT_","SalesOrderItem":"SOI_"
}

TABLE_MAP = {
    "Customer":        ("business_partners",         "businessPartner",  "businessPartnerName"),
    "SalesOrder":      ("sales_order_headers",       "salesOrder",       "salesOrder"),
    "BillingDocument": ("billing_documents",         "billingDocument",  "billingDocument"),
    "Plant":           ("plants",                    "plant",            "plantName"),
    "Delivery":        ("outbound_delivery_headers", "deliveryDocument", "deliveryDocument"),
    "JournalEntry":    ("journal_entry_items",       "accountingDocument","accountingDocument"),
}

@app.route("/api/graph/overview")
def graph_overview():
    conn = get_db()
    nodes = []

    def add(qsql, ntype, id_col, label_col=None):
        for r in conn.execute(qsql):
            d = dict(r)
            lbl = str(d.get(label_col or id_col, d.get(id_col, "?")))
            if len(lbl) > 20: lbl = lbl[:19] + "…"
            nodes.append({"id": NODE_PREFIX[ntype]+str(d[id_col]), "label": lbl,
                          "type": ntype, "data": d})

    add("SELECT businessPartner, businessPartnerName, businessPartnerIsBlocked FROM business_partners",
        "Customer", "businessPartner", "businessPartnerName")
    add("SELECT salesOrder, soldToParty, totalNetAmount, overallDeliveryStatus, creationDate FROM sales_order_headers LIMIT 25",
        "SalesOrder", "salesOrder")
    add("SELECT billingDocument, totalNetAmount, billingDocumentIsCancelled, soldToParty, creationDate FROM billing_documents LIMIT 20",
        "BillingDocument", "billingDocument")
    add("SELECT plant, plantName FROM plants LIMIT 15",
        "Plant", "plant", "plantName")
    add("SELECT deliveryDocument, creationDate, shippingPoint, overallGoodsMovementStatus FROM outbound_delivery_headers LIMIT 12",
        "Delivery", "deliveryDocument")
    add("SELECT accountingDocument, amountInTransactionCurrency, postingDate, customer FROM journal_entry_items LIMIT 10",
        "JournalEntry", "accountingDocument")

    seen_pay = set()
    for r in conn.execute("SELECT DISTINCT clearingAccountingDocument, amountInTransactionCurrency, clearingDate FROM payments WHERE clearingAccountingDocument IS NOT NULL LIMIT 8"):
        nid = "PAY_" + str(r["clearingAccountingDocument"])
        if nid not in seen_pay:
            seen_pay.add(nid)
            nodes.append({"id": nid, "label": f"PAY {r['clearingAccountingDocument']}",
                          "type": "Payment", "data": dict(r)})

    node_ids = {n["id"] for n in nodes}
    raw_edges = conn.execute("SELECT source_type, source_id, target_type, target_id, relationship FROM graph_edges").fetchall()
    edges, seen_e = [], set()
    for e in raw_edges:
        src = NODE_PREFIX.get(e["source_type"], e["source_type"]+"_") + e["source_id"]
        tgt = NODE_PREFIX.get(e["target_type"], e["target_type"]+"_") + e["target_id"]
        key = (src, tgt)
        if src in node_ids and tgt in node_ids and key not in seen_e:
            seen_e.add(key)
            edges.append({"source": src, "target": tgt, "label": e["relationship"]})

    conn.close()
    return jsonify({"nodes": nodes, "edges": edges})

@app.route("/api/graph/expand/<node_type>/<path:node_id>")
def expand_node(node_type, node_id):
    conn = get_db()
    nbrs = conn.execute(
        "SELECT * FROM graph_edges WHERE (source_type=? AND source_id=?) OR (target_type=? AND target_id=?) LIMIT 30",
        (node_type, node_id, node_type, node_id)
    ).fetchall()

    src_prefix = NODE_PREFIX.get(node_type, node_type+"_")
    new_nodes, new_edges = [], []

    for e in nbrs:
        e = dict(e)
        if e["source_type"] == node_type and e["source_id"] == node_id:
            nt, ni, direction = e["target_type"], e["target_id"], "out"
        else:
            nt, ni, direction = e["source_type"], e["source_id"], "in"

        prefix = NODE_PREFIX.get(nt, nt+"_")
        label, data = f"{nt} {ni}", {}

        if nt in TABLE_MAP:
            tbl, pk, lbl_col = TABLE_MAP[nt]
            row = conn.execute(f"SELECT * FROM {tbl} WHERE {pk}=? LIMIT 1", (ni,)).fetchone()
            if row:
                data = dict(row)
                label = str(data.get(lbl_col, ni))
                if len(label) > 20: label = label[:19] + "…"

        new_nodes.append({"id": prefix+ni, "label": label, "type": nt, "data": data})
        if direction == "out":
            new_edges.append({"source": src_prefix+node_id, "target": prefix+ni, "label": e["relationship"]})
        else:
            new_edges.append({"source": prefix+ni, "target": src_prefix+node_id, "label": e["relationship"]})

    conn.close()
    return jsonify({"nodes": new_nodes, "edges": new_edges})

# ── API: Direct SQL Query ───────────────────────────────────────────────────

@app.route("/api/query", methods=["POST"])
def direct_query():
    sql = (request.json or {}).get("sql", "").strip()
    if not sql.upper().startswith("SELECT"):
        return jsonify({"error": "Only SELECT queries are permitted"}), 400
    rows, err = run_query(sql)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"rows": rows, "count": len(rows)})

# ── API: Chat (NL → SQL → Answer) ──────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
def chat():
    body     = request.json or {}
    user_msg = body.get("message", "").strip()
    history  = body.get("history", [])

    if not user_msg:
        return jsonify({"error": "Empty message"}), 400

    client   = anthropic.Anthropic()
    messages = [{"role": h["role"], "content": h["content"]} for h in history[-8:]]
    messages.append({"role": "user", "content": user_msg})

    # ── Step 1: Generate SQL ────────────────────────────────────────────────
    r1  = client.messages.create(model="claude-sonnet-4-20250514", max_tokens=1500,
                                  system=SYSTEM_PROMPT, messages=messages)
    raw = r1.content[0].text.strip()

    # Guardrail check
    if raw.startswith("GUARDRAIL:"):
        return jsonify({
            "answer": raw[len("GUARDRAIL:"):].strip(),
            "sql": None, "data": [], "highlighted_nodes": [],
            "guardrail": True, "row_count": 0
        })

    # Parse JSON response
    parsed = {}
    try:
        m = re.search(r'\{.*\}', raw, re.DOTALL)
        parsed = json.loads(m.group() if m else raw)
    except Exception:
        # Non-JSON means either guardrail or plain text answer
        is_guard = any(kw in raw.lower() for kw in ["dataset only", "order-to-cash dataset", "cannot answer"])
        return jsonify({
            "answer": raw, "sql": None, "data": [], "highlighted_nodes": [],
            "guardrail": is_guard, "row_count": 0
        })

    sql         = parsed.get("sql", "")
    highlighted = parsed.get("highlighted_nodes", [])

    # ── Step 2: Execute SQL (with auto-fix on error) ────────────────────────
    query_rows, sql_error = [], None

    if sql and sql.strip().upper().startswith("SELECT"):
        query_rows, sql_error = run_query(sql)

        if sql_error:
            fix_msgs = messages + [
                {"role": "assistant", "content": raw},
                {"role": "user",      "content": f"SQL execution error: {sql_error}\nFix the SQL and return corrected JSON only."}
            ]
            r2  = client.messages.create(model="claude-sonnet-4-20250514", max_tokens=1000,
                                          system=SYSTEM_PROMPT, messages=fix_msgs)
            raw2 = r2.content[0].text.strip()
            try:
                m2 = re.search(r'\{.*\}', raw2, re.DOTALL)
                p2 = json.loads(m2.group() if m2 else raw2)
                sql = p2.get("sql", sql)
                query_rows, sql_error = run_query(sql)
                highlighted = p2.get("highlighted_nodes", highlighted)
            except Exception:
                pass

    # ── Step 3: Generate natural language answer from real results ──────────
    row_count = len(query_rows) if query_rows else 0
    preview   = json.dumps((query_rows or [])[:15], indent=2, default=str)

    final_msgs = messages + [
        {"role": "assistant", "content": raw},
        {"role": "user", "content":
            f"The SQL query returned {row_count} rows. Here are the results:\n{preview}\n\n"
            f"Write a clear, specific 2-4 sentence answer in plain text (no JSON, no markdown). "
            f"Cite actual values — customer names, amounts (in ₹), document IDs, counts — from the results. "
            f"If 0 rows, explain what the zero result means for the business (e.g. 'no broken flows found')."}
    ]
    r3     = client.messages.create(model="claude-sonnet-4-20250514", max_tokens=600,
                                     system=SYSTEM_PROMPT, messages=final_msgs)
    answer = r3.content[0].text.strip()

    # Strip JSON if model slipped back to it
    if answer.startswith("{"):
        try:
            fa = json.loads(answer)
            answer = fa.get("insight") or fa.get("answer") or answer
        except Exception:
            pass

    return jsonify({
        "answer":           answer,
        "sql":              sql,
        "data":             (query_rows or [])[:20],
        "highlighted_nodes": highlighted,
        "guardrail":        False,
        "sql_error":        sql_error,
        "row_count":        row_count,
    })

# ── Run ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    debug = os.environ.get("FLASK_ENV") == "development"
    print(f"O2C Graph Intelligence → http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug)
